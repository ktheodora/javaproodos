﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication7
{
    public partial class MovingObj : Form
    {
      //  enum Position {
       //     Right,Left,Up,Down 
      //  }
     
        private int x,y;
       // private Position mypos;
        public MovingObj()
        {
            InitializeComponent();
          //  bool level = false;
          //  mypos = Position.Down; //instead of position.Right
            //timer1.Start();
        }
        

        private void MovingObj_Load(object sender, EventArgs e)
        {

        }

        private void MovingObj_Paint(object sender, PaintEventArgs e)
        {
           /* e.Graphics.FillRectangle(Brushes.GreenYellow, x, y, 100, 100);
           // e.Graphics.DrawImage(new Bitmap("mushroom.png"), x, y, 64, 64); */
        }

        private void MovingObj_KeyDown(object sender, KeyEventArgs e)
        {
           /* if (e.KeyCode == Keys.Left)
            {
                mypos = Position.Left;
            }
            else if (e.KeyCode == Keys.Right)
            {
                mypos = Position.Right;
            }
            else if (e.KeyCode == Keys.Up)
            {
                mypos = Position.Up;
            }
            else if (e.KeyCode == Keys.Down)
            {
                mypos = Position.Down;
            } */
        }
        public Random r = new Random();
        int timeLeft, counter = 0;

        private void pictureBox1_MouseClick(object sender, MouseEventArgs e)
        {
            counter++;
            clickscount.Text = counter.ToString() + " Click(s)";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            panel1.Visible = false;
            timeremain.Visible = true;
            clickscount.Visible = true;
            timeLeft = 30;
            timeremain.Text = "Time left: 30 seconds";
            timer1.Start();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {

             x = r.Next(0, 925);
             y = r.Next(0, 445);
            pictureBox1.Top = y;
            pictureBox1.Left = x;

            if (timeLeft > 0)
            {
                // Display the new time left
                // by updating the Time Left label.
                timeLeft = timeLeft - 1;
                timeremain.Text = "Time left: " + timeLeft + " seconds";
            }
            else
            {
                // If the user ran out of time, stop the timer, show
                // a MessageBox, and fill in the answers.
                timer1.Stop();
                timeremain.Text = "Time's up!";
                if (MessageBox.Show("Game over! Your score is " + counter.ToString() + " clicks!") == DialogResult.OK ) {
                    counter = 0;
                    panel1.Visible = true;
                    timeremain.Visible = false;
                    clickscount.Visible = false;
                }             

            }

            /* Gia na kineitai me velakia
            if (mypos == Position.Right)
            {
               x += 10;
            }
            else if (mypos == Position.Left)
            {
                x -= 10;
            }
            else if (mypos == Position.Up)
            {
                y -= 10;
            }
            else if (mypos == Position.Down)
            {
                y += 10;
            }

            Invalidate();
            */




            /* int bottomBorder = 369;
             int rightBorder = 800;
             int topBorder = 0;
             int leftBorder = -100;
             Random r = new Random();
             int Dice = r.Next(4);


             if (Dice==1)
             {
                 if ((x + 200) > rightBorder)
                 {
                     x = rightBorder;
                 }
                 else
                 {
                     x += 250;

                 }
             }
             else if (Dice==2)
             {
                 if ((x -20) > leftBorder)
                 {
                     x = leftBorder;

                 }
                 else
                 {
                     x -= 20;
                 }

             }
             else if (Dice==3)
             {
                 if ((y + 20) > topBorder)
                 {
                     y = topBorder;
                 }
                 else
                 {
                     y += 20;
                 }
             }
             else
             {
                 if ((y-200)<bottomBorder)
                 {
                     y = bottomBorder;
                 }
                 else
                 {
                     y -=200;
                 }
             }





             Invalidate(); */

        }

    }
}
